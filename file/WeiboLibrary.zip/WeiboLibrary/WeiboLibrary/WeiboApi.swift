//
//  WeiboApi.swift
//  WeiboLibrary
//
//  Created by jianghui liu on 2022/5/2.
//

import Foundation
@objcMembers
public class WeiboApi : NSObject {
    public override init() {
        super.init()
    }
    public func hello(b : Int) {
        
    }
}
