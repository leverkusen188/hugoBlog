//
//  CountryCell.swift
//  WeiboLibrary
//
//  Created by jianghui liu on 2022/5/2.
//

import Foundation
import UIKit
import RxCocoa
import RxSwift
//import Masonry
import SnapKit


class CountryCell : UICollectionViewCell {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    var code : String = ""
    
    lazy var headerImage : UIImageView = {
        let imageView = UIImageView()
        imageView.image = UIImage(weiboImgName: "default_indark")
        self.contentView.addSubview(imageView)
        return imageView
    }()
    
    lazy var name : UILabel = {
        let label = UILabel()
        label.text = "UserName"
        label.textColor = .black
        label.font = UIFont(name: "", size: 15.0)
        self.contentView.addSubview(label)
        return label
    }()
    
    lazy var contentLabel : UILabel = {
        let label = UILabel()
        label.text = "Content"
        label.textColor = .gray
        label.numberOfLines = 0
        self.contentView.addSubview(label)
        return label
    }()
    
    lazy var timeLabel : UILabel = {
        let label = UILabel()
        label.text = "Time"
        label.textColor = .gray
        label.numberOfLines = 0
        label.font = UIFont(name: "", size: 11.0)
        self.contentView.addSubview(label)
        return label
    }()
    
    func idenityWidth() -> Float {
        return 10
    }
    
    func nameBinding(name : String, code : String) {
        self.name.text = "国家: (\(name))"
        self.code = code
    }
    
    private func setupUI() {
        //左上角
        headerImage.snp.makeConstraints { make in
            make.left.top.equalTo(10)
            make.width.equalTo(self.idenityWidth())
        }
        name.snp.remakeConstraints { make in
            make.centerY.equalTo(headerImage)
            make.left.equalTo(headerImage.snp.right).offset(10.0)
        }

        //下面
//        contentLabel.snp.remakeConstraints { make in
//            make.left.equalTo(headerImage)
//            make.top.equalTo(headerImage.snp.bottom).offset(10.0)
//            make.bottom.equalTo(self.contentView.snp.bottom).offset(-10)
//        }

        //右上角
//        self.timeLabel.snp.makeConstraints { make in
//            make.centerY.equalTo(headerImage)
//            make.right.equalTo(self.contentView.snp.right).offset(-10.0)
//        }
    }
}


class ProvinceCell : CountryCell {
    override func idenityWidth() -> Float {
        return 50
    }
    
    override func nameBinding(name: String, code : String) {
        super.nameBinding(name: name, code: code)
        self.name.text = "省份: \(name)"
    }
}

class CityCell : ProvinceCell {
    override func idenityWidth() -> Float {
        return 100
    }
    
    override func nameBinding(name: String, code : String) {
        super.nameBinding(name: name, code: code)
        self.name.text = "城市: \(name)"
    }
}


