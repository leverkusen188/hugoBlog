//
//  WeiboModel+New.swift
//  WeiboLibrary
//
//  Created by jianghui liu on 2022/5/10.
//

import Foundation
import RxSwift


struct WeiboModelUIAction {
    var loadMainAction = PublishSubject<Void>()
    
    
}

extension WeiboModel {
    
}
