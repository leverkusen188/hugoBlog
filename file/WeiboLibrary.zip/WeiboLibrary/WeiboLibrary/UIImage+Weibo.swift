//
//  UIImage+Weibo.swift
//  WeiboLibrary
//
//  Created by jianghui liu on 2022/5/5.
//

import Foundation
import UIKit

public extension UIImage {
    convenience init?(weiboImgName : String) {
        if let bundle = Bundle.weiboBundle() {
            self.init(named: weiboImgName, in: bundle, with: nil)
        }
        else {
            self.init(named: weiboImgName)
        }
    }
    static func weiboImage(_ name : String) -> UIImage? {
        if let bundle = Bundle.weiboBundle() {
            return UIImage(named: name, in: bundle, with: nil)
        }
        return nil
    }
}


public extension Bundle {
    static func weiboBundle() -> Bundle? {
        let framework = self.main.url(forResource: "WeiboLibrary", withExtension: "framework", subdirectory: "Frameworks")
        if framework != nil {
            return Bundle(url: framework!)
        }
        return nil
    }
}
