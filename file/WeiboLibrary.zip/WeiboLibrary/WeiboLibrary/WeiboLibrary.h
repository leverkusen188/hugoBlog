//
//  WeiboLibrary.h
//  WeiboLibrary
//
//  Created by jianghui liu on 2022/5/2.
//

#import <Foundation/Foundation.h>
//#import "WeiboLibrary-Swift.h"
#import "WeiboSDK.h"

//! Project version number for WeiboLibrary.
FOUNDATION_EXPORT double WeiboLibraryVersionNumber;

//! Project version string for WeiboLibrary.
FOUNDATION_EXPORT const unsigned char WeiboLibraryVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WeiboLibrary/PublicHeader.h>


