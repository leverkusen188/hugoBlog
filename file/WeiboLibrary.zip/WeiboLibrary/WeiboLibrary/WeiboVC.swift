//
//  WeiboVC.swift
//  WeiboLibrary
//
//  Created by jianghui liu on 2022/5/2.
//

import Foundation
import UIKit
import RxCocoa
import RxSwift
import SnapKit
import SwiftUI

@objcMembers
public class WeiboVC : UIViewController {
    static let CountryCellId = "CountryCell"
    static let ProvinceCellId = "ProvinceCell"
    static let CityCellId = "CityCell"
    
    let allBag = DisposeBag()
    var listBindingBag : Disposable?
    var requestingBag : Disposable?
    
    let model = WeiboModel()
    
    deinit {
        print("")
    }
    
    var alert : LoadingAlert?
    lazy var loginBtn : UIButton = {
        let btn = UIButton(type: .system)
        btn.setTitle("登录", for: .normal)
        btn.setTitle("注销", for: .selected)
        self.view.addSubview(btn)
        btn.snp.remakeConstraints { make in
            make.left.top.equalTo(10)
        }
        
        return btn
    }()
    
    lazy var userNameLabel : UILabel = {
        let label = UILabel()
        label.text = ""
        label.textColor = .black
        label.font = UIFont(name: "", size: 15.0)
        self.view.addSubview(label)
        label.snp.makeConstraints { make in
            make.left.equalTo(loginBtn.snp.right).offset(10)
            make.centerY.equalTo(loginBtn)
        }
        return label
    }()
    
    //微博timeline
    lazy var collectionView : UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width: self.view.bounds.width, height: 50)
        layout.minimumLineSpacing = 5.0
        let collectionView = UICollectionView(frame: CGRect(x: 0, y: 100, width: self.view.bounds.width, height: self.view.bounds.height - 100), collectionViewLayout: layout)
        collectionView.layer.borderColor = UIColor.gray.cgColor
        collectionView.layer.borderWidth = 2.0
        collectionView.register(CountryCell.self, forCellWithReuseIdentifier: WeiboVC.CountryCellId)
        collectionView.register(ProvinceCell.self, forCellWithReuseIdentifier: WeiboVC.ProvinceCellId)
        collectionView.register(CityCell.self, forCellWithReuseIdentifier: WeiboVC.CityCellId)
        self.view.addSubview(collectionView)
        collectionView.snp.makeConstraints { make in
            make.left.right.bottom.equalTo(self.view)
            make.top.equalTo(100)
        }
        return collectionView
    }()
    override public func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
    }
    override public func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        bindRX()
        
    }
}

/**  NEW **/
extension WeiboVC {
    func bindRX() {
        //UI Action binds to model observers
        loginBtn.rx.tap
            .map({ _ in
                -1
            })
            .bind(to: model.loadSubAction)
            .disposed(by: allBag)
        
        collectionView.rx.itemSelected
            .map { index in
                index.row
            }.bind(to: model.loadSubAction)
            .disposed(by: allBag)
        
        //bind data observables
        model.countryDataLoader
            .bind(to: self.collectionView.rx.items, curriedArgument: { [weak self] (collection, row, model) -> UICollectionViewCell in
                return self?.reloadCell(row: row, model: model) ?? UICollectionViewCell()
            }).disposed(by: allBag)
    }
}

/** OLD **/
extension WeiboVC {
    
    func reloadCell(row : Int, model : InfoProperty) -> UICollectionViewCell {
        if model is ProvinceInfo {
            let cell = self.collectionView.dequeueReusableCell(withReuseIdentifier: WeiboVC.ProvinceCellId, for: NSIndexPath(row: row, section: 0) as IndexPath) as! ProvinceCell
            
            cell.nameBinding(name: model.name, code: model.code)
            return cell
        }
        else if model is CityInfo {
            let cell = self.collectionView.dequeueReusableCell(withReuseIdentifier: WeiboVC.CityCellId, for: NSIndexPath(row: row, section: 0) as IndexPath) as! CityCell
            
            cell.nameBinding(name: model.name, code: model.code)
            return cell
        }
        else {
            let cell = self.collectionView.dequeueReusableCell(withReuseIdentifier: WeiboVC.CountryCellId, for: NSIndexPath(row: row, section: 0) as IndexPath) as! CountryCell
            
            cell.nameBinding(name: model.name, code: model.code)
            return cell
        }
    }
}
